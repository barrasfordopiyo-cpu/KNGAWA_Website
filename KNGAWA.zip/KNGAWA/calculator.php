<?php
use CommonMark\Node\Text\Strong;
date_default_timezone_set("Africa/Nairobi");
require_once 'session.php';
require_once 'class.php';
$db = new db_class();
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Loan Calculator</title>

    <link href="fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  
   
    <link href="css/sb-admin-2.css" rel="stylesheet">
	
	<!-- Custom styles for this page -->
    <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
    

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-text mx-3">ADMIN PANEL</div>
            </a>


            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="home_member.php">
                    <i class="fas fa-fw fa-home"></i>
                    <span>Home</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="loan_member.php">
                    <i class="fas fa-fw fas fa-comment-dollar"></i>
                    <span>Loan History</span></a>
            </li>
			<li class="nav-item active">
                <a class="nav-link" href="payment_member.php">
                    <i class="fas fa-fw fas fa-coins"></i>
                    <span>Payment History</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="calculator.php">
                    <i class="fas fa-fw fas fa-coins"></i>
                    <span>Loan calculator</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="apply.php">
                    <i class="fas fa-fw fa-piggy-bank"></i>
                    <span>Apply for a loan</span></a>
            </li>
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
	
                   
					<!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $db->user_acc($_SESSION['user_id']) ?></span>
                                <img class="img-profile rounded-circle"
                                    src="image/admin_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    

                    <!-- Content Row -->
                    <div class="row">
                        <!-- Earnings (Monthly) Card Example -->
                      <?php
                      // Initialize variables to avoid PHP notices if the form hasn't been submitted
                      $loan_amount = '';
                      $days = '';
                      $total_loan = '';


                      // Check if the form has been submitted
                      if ($_SERVER["REQUEST_METHOD"] == "POST") {
                          // Collect and sanitize user input
                          $loan_amount = $_POST['loan_amount'];
                          $days = $_POST['days'];



                          if ($days > 30) {

                              $total_loan = $loan_amount + ($loan_amount * $days * 0.0024) + ($loan_amount * $days * 0.0027);
                              // Changed to return the value for better reusability





                          } else {
                              $total_loan = $loan_amount + ($loan_amount * $days * 0.0024);

                          }
                      }
?>
                                                                

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <style>
        body { font-family: Arial, sans-serif; }
        .container { width: 500px; margin: 50px auto; padding: 20px; border: 1px solid #ccc; border-radius: 5px; }
        .form-group { margin-bottom: 15px; font-weight: 700}
        label { display: block; margin-bottom: 5px; }
        input[type="number"] { width: 100%; padding: 8px; box-sizing: border-box; }
        .result { margin-top: 20px; padding: 20px; background-color: lightblue; font-size: 18px; border: 1px solid #ddd; }
    </style>
</head>
<body>

<div class="container">
    <h2>KNGAWA Loan Calculator</h2>
    <form method="post" attribute="post" action="calculator.php">
        <div class="form-group">
            <label for="loan_amount">Principal Amount (Ksh.):</label>
            <input type="number" id="loan_amount" name="loan_amount" step="100" required value="<?php echo $loan_amount; ?>">
        </div>
        <div class="form-group">
            <label for="days">Period (days):</label>
            <input type="number" id="days" name="days" required value="<?php echo $days; ?>">
        </div>
        <div class="form-group">
            <button type="submit" name="total_loan" id="total_loan" value="total_loan">Calculate total loan</button>
        </div>
    </form>
    <?php if ($total_loan !== ''): ?>
        <div class="result">
           <?php echo "<strong>After $days days, you will pay back Ksh. $total_loan</strong>"?>;
        </div>
    <?php endif; ?>
    </div>
    </div>
                   

</body>
</html>

            <!-- End of Main Content -->

            <!-- Footer -->
            
            <!-- End of Footer -->


        <!-- End of Content Wrapper -->


    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger">
                    <h5 class="modal-title text-white">System Information</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">�</span>
                    </button>
                </div>
                <div class="modal-body">Are you sure you want to log out?</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-danger" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>
	
    <!-- Bootstrap core JavaScript-->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.bundle.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="js/jquery.easing.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.js"></script>
	
	<!-- Page level plugins -->
	<script src="js/jquery.dataTables.js"></script>
    <script src="js/dataTables.bootstrap4.js"></script>
	
	<script>
		$(document).ready(function() {
			$('#dataTable').DataTable({
				"order": [[1 , "asc" ]]
			});
		});
	</script>


