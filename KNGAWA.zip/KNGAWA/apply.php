
 <?php
 date_default_timezone_set("Africa/Nairobi");
 require_once 'session.php';
 require_once 'class.php';
 $db = new db_class();
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
	<style>
		input[type=number]::-webkit-inner-spin-button, 
		input[type=number]::-webkit-outer-spin-button{ 
			-webkit-appearance: none; 
		}

	</style>
	
	
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Loan Application</title>

    <link href="fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  
   
    <link href="css/sb-admin-2.css" rel="stylesheet">
    
	<!-- Custom styles for this page -->
    <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="css/select2.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-text mx-3">MEMBER PANEL</div>
            </a>


            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="home_member.php">
                    <i class="fas fa-fw fa-home"></i>
                    <span>Home</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="loan_member.php">
                    <i class="fas fa-fw fas fa-comment-dollar"></i>
                    <span>Loan History</span></a>
            </li>
			<li class="nav-item active">
                <a class="nav-link" href="payment_member.php">
                    <i class="fas fa-fw fas fa-coins"></i>
                    <span>Payment History</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="calculator.php">
                    <i class="fas fa-fw fas fa-coins"></i>
                    <span>Loan calculator</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="apply.php">
                    <i class="fas fa-fw fa-piggy-bank"></i>
                    <span>Apply for a loan</span></a>
            </li>
			
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
	
                   
					<!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $db->user_acc($_SESSION['user_id']) ?></span>
                                <img class="img-profile rounded-circle"
                                    src="image/admin_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->

					
                    <!-- Content Row -->
                   

                    <div class="card shadow mb-2">
                        <div class="card-body">

                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                <tr>

                                    <th>Your loan limit</th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                $tbl_contributions=$db->display_contributions();
                                while($fetch=$tbl_contributions->fetch_array()){
                                    ?>
                                    <tr>

                                        <td><strong><?php echo $fetch['loan_limit'] ?><strong></td>

                                    </tr>

                                    <?php
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

<?php
$servername = "localhost";
$username = "kngawac1_Admin";
$password = "";
$dbname = "kngawac1_kngawa";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

                                        $loan_amount = "";
$days = "";
$guarantor = "";
$guarantor_name = "";
$guarantor_contact = "";
$guarantor_amount = "";
$agree = "";
$message = "";
$toastClass = "";
$loan_limit = "";


if (isset($_POST['add_application'])) {
    
    $loan_amount = $_POST['loan_amount'];
    $days = $_POST['days'];
    $guarantor = $_POST['guarantor'];
    $guarantor_name = $_POST['guarantor_name'];
    $guarantor_contact = $_POST['guarantor_contact'];
    $guarantor_amount = $_POST['guarantor_amount'];
    $agree = $_POST['agree'];



    // Prepare and execute the SQL statement
    $query = $conn->prepare("INSERT INTO application (loan_amount, days, guarantor, guarantor_name, guarantor_contact, guarantor_amount, agree) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $query->bind_param("sssssss", $loan_amount, $days, $guarantor, $guarantor_name, $guarantor_contact, $guarantor_amount, $agree);


    if ($query->execute()) {
        $message = "Application submitted successfully";
        $toastClass = "#28a745"; // Success color


    } else {
        $message = "Error: " . $query->error;
        $toastClass = "#dc3545"; // Danger color
    }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href=
"https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href=
"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <link rel="shortcut icon" href=
"https://cdn-icons-png.flaticon.com/512/295/295128.png">
    <script src=
"https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    
</head>

<body class="bg-light">
    <div class="container p-5 d-flex flex-column align-items-center">
        <?php if ($message): ?>
            <div class="toast align-items-center text-white border-0" 
          role="alert" aria-live="assertive" aria-atomic="true"
                style="background-color: <?php echo $toastClass; ?>;">
                <div class="d-flex">
                    <div class="toast-body">
                        <?php echo $message; ?>
                    </div>
                    <button type="button" class="btn-close
                    btn-close-white me-2 m-auto" 
                          data-bs-dismiss="toast"
                        aria-label="Close"></button>
               
            </div>
        <?php endif; ?>
                <form method="post" class="form-control mt-5 p-4" name="add_application"
                      style="height:auto; width:520px; font-weight:700;
            border-radius: 10px; display: inline-block; vertical-align: middle;
            box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px,
            rgba(60, 64, 67, 0.15) 0px 2px 6px 2px;">


                    <div class="row text-center">

                        <i class="align-content-center">
                            <i class="fa fa-user-circle-o fa-3x mt-1 mb-2" style="color: green;align-content: center"></i>
                            <h5 class="p-4" style="font-weight: 700;">Loan Application Form</h5>

                    </div>

            <div class="mb-2 mt-2">
                <label for="loan_amount"><i 
                  class="fa fa-money"></i> Amount you want to apply</label>
                <input type="number" name="loan_amount" id="loan_amount"
                  class="form-control" required>
            </div>
            <div class="mb-2 mt-2">
                <label for="days"><i 
                  class="fa fa-calendar"></i> Period (in days)</label>
                <input type="number" name="days" id="days"
                  class="form-control" required>
            </div>
            <div class="mb-2 mt-2">
                <label for="guarantor">Guarantor</label>
                <select name="guarantor" class="form-control" required>
                    <option value="">---Do you need a guarantor---</option>"
                       <option value="Yes">Yes</option>"
                    <option value="No">No</option>"
                    </select>
               
            </div>
            <div class="mb-2 mt-2">
                <label for="guarantor_name"><i 
                  class="fa fa-user"></i> If yes, give the name of the guarantor</label>
                <input type="text" name="guarantor_name" id="guarantor_name"
                  class="form-control" >
            
            </div>
            <div class="mb-2 mt-2">
                <label for="guarantor_contact"><i 
                  class="fa fa-phone"></i>Guarantor's phone number'</label>
                <input type="number" name="guarantor_contact" id="guarantor_contact"
                  class="form-control" >
            </div>
            <div class="form-group">
                <label for="guarantor_amount"><i 
                  class="fa fa-coins"></i>How much money would you like to be guaranteed?</label>
                <input type="number" name="guarantor_amount" id="guarantor_amount"
                  class="form-control" >
            </div>
    <div class="mb-2 mt-2">
                <label for="agree">Declaration: I commit to pay all my loans in good time. Further, I understand that should I default on my loan, KNGAWA will undertake all measures necessary to recover the loan.</label>
                <select name="agree" class="form-control"required>
                    <option value="">---You must agree to Terms for you to proceed with application---</option>"
                       <option value="Agree">I agree</option>"
                   
                    </select>
                
                </div>
            <div class="mb-2 mt-3">
                <button type="submit" 
                  class="btn btn-success
                bg-success" name ="add_application" style="font-weight: 600;">Apply
                    </button>
            </div>
            <div class="mb-2 mt-4">
                <p class="text-center" style="font-weight: 600; 
                color: navy;">Need to use the loan calculator? <a href="./calculator.php"
                        style="text-decoration: none;">Loan Calculator</a></p>
            </div>
        </form>
    </div>
    <script>
        let toastElList = [].slice.call(document.querySelectorAll('.toast'))
        let toastList = toastElList.map(function (toastEl) {
            return new bootstrap.Toast(toastEl, { delay: 3000 });
        });
        toastList.forEach(toast => toast.show());
    </script>
</body>

</html>
