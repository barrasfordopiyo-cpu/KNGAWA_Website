<?php
date_default_timezone_set('Africa/Nairobi');

require_once 'class.php';
$db = new db_class();
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Welcome Page</title>
    <link href="fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  
   
    <link href="css/sb-admin-2.css" rel="stylesheet">
    

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-text mx-3">VISITOR PANEL</div>
            </a>


            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="about.php">
                    <i class="fas fa-fw fa-book"></i>
                    <span>About Us</span></a>
            </li>
            
            <li class="nav-item active">
                <a class="nav-link" href="contact.php">
                    <i class="fas fa-fw fa-address-book"></i>
                    <span>Contact Us</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="news.php">
                    <i class="fas fa-fw fas fa-television"></i>
                    <span>News and Blogs</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="management.php">
                    <i class="fas fa-fw fas fa-group"></i>
                    <span>Management</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="join.php">
                    <i class="fas fa-fw fas fa-pen-fancy"></i>
                    <span>Why join us</span></a>
            </li>
			
			
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
	
                   
					<!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo "Visitor's Account"?></span>
                                <img class="img-profile rounded-circle"
                                    src="image/admin_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        
                        
                    </div>

                    <!-- Content Row -->
                   <?php


                   $servername = "localhost";
                   $username = "kngawac1_Admin";
                   $password = "MySQLAdmin!";
                   $dbname = "kngawac1_kngawa";

                   // Create connection
                   $conn = mysqli_connect($servername, $username, $password, $dbname);

                   // Check connection
                   if (!$conn) {
                       die("Connection failed: " . mysqli_connect_error());
                   }

                   
                   $message = "";
                   $toastClass = "";
                   $firstname = " ";
                   $other_names = " ";
                   $lastname = " ";
                   $user_type = "";
                   $username = "";
                   $password = "";
                   $password1 = "";
                   $natid = "";
                   $payroll = "";
                   $gender = "";
                   $contact = "";
                   $alt_contact = "";
                   $email = "";
                   $kin = "";
                   $kin_contact = "";
                   $foster = "";
                   $foster1 = "";
                   $foster2 = "";
                   $parents = "";
                   $accept_tnc = "";

                   if (isset($_POST['add_user'])) {
                       $firstname = $_POST['firstname'];
                       $lastname = $_POST['lastname'];
                       $other_names = $_POST['other_names'];
                       $user_type = $_POST['user_type'];
                       $username = $_POST['username'];
                       $password = $_POST['password'];
                       $password1 = $_POST['password1'];
                       $natid = $_POST['natid'];
                       $payroll = $_POST['payroll'];
                       $gender = $_POST['gender'];
                       $contact = $_POST['contact'];
                       $alt_contact = $_POST['alt_contact'];
                       $email = $_POST['email'];
                       $kin = $_POST['kin'];
                       $kin_contact = $_POST['kin_contact'];
                       $foster = $_POST['foster'];
                       $foster1 = $_POST['email'];
                       $foster2 = $_POST['foster2'];
                       $parents = $_POST['parents'];
                       $accept_tnc = $_POST['accept_tnc'];

                       // Check if email already exists
                       $checkEmailStmt = $conn->prepare("SELECT email FROM user WHERE email = ?");
                       $checkEmailStmt->bind_param("s", $email);
                       $checkEmailStmt->execute();
                       $checkEmailStmt->store_result();

                       // Check if username already exists
                       $checkusernameStmt = $conn->prepare("SELECT username FROM user WHERE username = ?");
                       $checkusernameStmt->bind_param("s", $username);
                       $checkusernameStmt->execute();
                       $checkusernameStmt->store_result();

                       //Check if  contact already exists
                       $checkcontactStmt = $conn->prepare("SELECT contact FROM user WHERE contact = ?");
                       $checkcontactStmt->bind_param("s", $contact);
                       $checkcontactStmt->execute();
                       $checkcontactStmt->store_result();

                       // Check if alternative contact already exists
                       $checkaltcontactStmt = $conn->prepare("SELECT alt_contact FROM user WHERE alt_contact = ?");
                       $checkaltcontactStmt->bind_param("s", $alt_contact);
                       $checkaltcontactStmt->execute();
                       $checkaltcontactStmt->store_result();

                       // Check if national ID already exists
                       $checknatidStmt = $conn->prepare("SELECT natid FROM user WHERE natid = ?");
                       $checknatidStmt->bind_param("s", $natid);
                       $checknatidStmt->execute();
                       $checknatidStmt->store_result();

                       // Check if payroll number already exists
                       $checkpayrollStmt = $conn->prepare("SELECT payroll FROM user WHERE payroll = ?");
                       $checkpayrollStmt->bind_param("s", $payroll);
                       $checkpayrollStmt->execute();
                       $checkpayrollStmt->store_result();

                       $message = "Check complete.";
                       $toastClass = "#28a745"; // Success color

                       if ($checkEmailStmt->num_rows > 0) {
                           $message = "Email ID already exists";
                           $toastClass = "#007bff"; // Primary color
                   
                       } elseif ($password !== $password1) {
                           $message = "The two passwords do not match";
                       } elseif ($checkusernameStmt->num_rows > 0) {
                           $message = "The username is already taken.";
                           $toastClass = "#28a745"; // Danger color
                       } elseif ($checkcontactStmt->num_rows > 0) {
                           $message = "A user is already registered with that phone number.";
                           $toastClass = "#28a745"; // Danger color
                       } elseif ($checkaltcontactStmt->num_rows > 0) {
                           $message = "A user is already registered with that phone number.";
                           $toastClass = "#28a745"; // Danger color
                       } elseif ($checknatidStmt->num_rows > 0) {
                           $message = "The ID number already exists.";
                           $toastClass = "#28a745"; // Danger color
                       } elseif ($checkpayrollStmt->num_rows > 0) {
                           $message = "A user is already registered with that payroll number.";
                           $toastClass = "#28a745"; // Danger color
                           
                       } else {
                           // Prepare and bind
                           $stmt = $conn->prepare("INSERT INTO user (firstname, lastname, other_names, user_type, username, password, natid, payroll, gender, contact, alt_contact, email, kin, kin_contact, foster, foster1, foster2, parents, accept_tnc) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                           $stmt->bind_param("sssssssssssssssssss",$firstname, $lastname, $other_names, $user_type, $username, $password, $natid, $payroll, $gender, $contact, $alt_contact, $email, $kin, $kin_contact, $foster, $foster1, $foster2, $parents, $accept_tnc);

                           if ($stmt->execute()) {
                               $message = "Account created successfully.";
                               $toastClass = "#28a745"; // Success color


                               echo"<script>window.location='index.php'</script>";

                               return true;
                           } else {
                               $message = "Error: " . $stmt->error;
                               $toastClass = "#dc3545"; // Danger color
                           }
                       
                              
                       }

	



                   }

                       
                   ?>

                    <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href=
"https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href=
"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <link rel="shortcut icon" href=
"https://cdn-icons-png.flaticon.com/512/295/295128.png">
    <script src=
"https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>Registration</title>
</head>

<body class="bg-bold">
    <div class="container p-5 d-flex flex-column align-items-center">
        <?php if ($message): ?>
            <div class="toast align-items-center text-white border-0" 
          role="alert" aria-live="assertive" aria-atomic="true"
                style="background-color: <?php echo $toastClass; ?>;">
                <div class="d-flex">
                    <div class="align-content-center">
                        <div class="display: inline-block">
                            
                                
                    <div class="toast-body">
                        <?php echo $message; ?>
                    </div>
                    <button type="button" class="btn-close
                    btn-close-white me-2 m-auto" 
                          data-bs-dismiss="toast"
                        aria-label="Close"></button>
                </div>
            </div>
        <?php endif; ?>
        <form method="post" class="form-control mt-5 p-4" name="add_user"
            style="height:auto; width:520px; font-weight:700;
            border-radius: 10px; display: inline-block; vertical-align: middle;
            box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px,
            rgba(60, 64, 67, 0.15) 0px 2px 6px 2px;">
      
  
            <div class="row text-center">
                
                    <i class="align-content-center">
                <i class="fa fa-user-circle-o fa-3x mt-1 mb-2" style="color: green;align-content: center"></i>
                <h5 class="p-4" style="font-weight: 700;">Create Your Account</h5>
            
             </div>
            <div class="mb-2 mt-2">
                <label for="firstname"><i 
                  class="fa fa-user"></i> First name</label>
                <input type="text" name="firstname" id="firstname"
                  class="form-control" required>
                
            </div>
            <div class="mb-2 mt-2">
                <label for="other_names"><i 
                  class="fa fa-user"></i> Other names</label>
                <input type="text" name="other_names" id="other_names"
                  class="form-control" required>
            </div>
            <div class="mb-2 mt-2">
                <label for="surname"><i 
                  class="fa fa-user"></i> Surname</label>
                <input type="text" name="lastname" id="lastname"
                  class="form-control" required>
            
     </div>
            <div class="mb-2 mt-2">
                <label for="user_type">User Type</label>
                <select name="user_type" class="form-control" required>
                    <option value="">---Select user type---</option>"
                       <option value="Member">Member</option>"
                    <option value="Admin">Admin</option>"
                    </select>
               
            </div>
            <div class="mb-2 mt-2">
                <label for="username"><i 
                  class="fa fa-user"></i> Username</label>
                <input type="text" name="username" id="username"
                  class="form-control" required>
                </div>
            <div class="mb-2 mt-2">
                <label for="password"><i 
                  class="fa fa-lock"></i> Password</label>
                <input type="password" name="password" id="password"
                  class="form-control" required>
                
            <div class="mb-2 mt-2">
                <label for="password1"><i 
                  class="fa fa-lock"></i> Confirm Password</label>
                <input type="password" name="password1" id="password1"
                  class="form-control" required>
                 </div>
               <div class="mb-2">
                <label for="natid"><i 
                  class="fa fa-id-card"></i> National ID. number</label>
                <input type="number" name="natid" id="natid"
                  class="form-control" required>
               
            </div>
                 
               <div class="mb-2 mt-2">
                <label for="payroll"><i 
                  class="fa fa-money-bill"></i> Payroll number</label>
                <input type="number" name="payroll" id="payroll"
                  class="form-control" required>
               
            
                </div>
            <div class="mb-2 mt-2">
                <label for="gender">Gender</label>
                <select name="gender" class="form-control">
                    <option value="">---Select your gender---</option>"
                       <option value="Male">Male</option>"
                    <option value="Female">Female</option>"
                    <option value="Intersex">Intersex</option>"
                    </select>
                
            
            </div>

                <div class="mb-2 mt-2">
                <label for="contact"><i 
                  class="fa fa-phone"></i> Phone number</label>
                <input type="number" name="contact" id="contact"
                  class="form-control" required>
               
            
                </div>
                <div class="mb-2 mt-2">
                <label for="alt_contact"><i 
                  class="fa fa-phone"></i> Alternative phone number</label>
                <input type="number" name="alt_contact" id="alt_contact"
                  class="form-control" required>
               
            
                </div>
            <div class="mb-2 mt-2">
                <label for="email"><i 
                  class="fa fa-envelope"></i> Email address</label>
                <input type="email" name="email" id="email"
                  class="form-control" required>
                 
               <div class="mb-2 mt-2">
                <label for="kin"><i 
                  class="fa fa-user"></i> Name of your next of kin</label>
                <input type="text" name="kin" id="kin"
                  class="form-control" required>
               </div>
                 
               <div class="mb-2 mt-2">
                <label for="kin_contact"><i 
                  class="fa fa-phone"></i> Phone number of your next of kin</label>
                <input type="text" name="kin_contact" id="kin_contact"
                  class="form-control" required>

                </div>
            <div class="mb-2 mt-2">
                <label for="foster">Fostership</label>
                <select name="foster" class="form-control" required>
                    <option value="">---Indicate whether you were brought up by foster parent(s)---</option>"
                       <option value="Yes">I was brought up by foster parent(s)</option>"
                    <option value="No">I was NOT brought up by foster parent(s)</option>"
                    </select>
                </div>
                <div class="mb-2 mt-2">
                <label for="foster1"><i 
                  class="fa fa-user"></i> If the foster parent(s) is(are) still alive, please provide their name(s):</label>
                <input type="text" name="foster1" id="foster1"
                  class="form-control" >

                     </div>
                <div class="mb-2 mt-2">
                <label for="foster2"><i 
                  class=""></i></label>
                <input type="text" name="foster2" id="foster2"
                  class="form-control" >
               
            
            </div>
            <div class="mb-2">
                <label for="parents">Are your parents still alive?</label>
                <select name="parents" class="form-control" required>
                    <option value="">---Select from the options below---</option>"
                       <option value="Both_Parents_Alive">Both Parents Alive</option>"
                    <option value="One_Parent_Alive">One Parent Alive</option>"
                    <option value="Total_Orphan">Total orphan</option>"
                    </select>
                
            </div>
                </div>
            <div class="mb-2">
                <label for="accept_tnc">Declaration: I agree to abide by the rules and regulations that govern KNGAWA. I also acknowledge that providing false information will lead to legal culpability as outlined in Penal Code(Cap. 63).</label>
                <select name="accept_tnc" class="form-control">
                    <option value="">---You must agree to Terms and Conditions to proceed with your registration---</option>"
                       <option value="Agree">I agree to the terms and conditions</option>"
                   
                    </select>
                
                </div>
            </div>
            <div class="mb-2 mt-3">
                <button type="submit" 
                  class="btn btn-success 
                bg-success" name ="add_user" style="font-weight: 600;">Create
                    Account</button>
            </div>
            <div class="mb-2 mt-4">
                <p class="text-center" style="font-weight: 600; 
                color: navy;">Already have an Account? <a href="./index.php"
                        style="text-decoration: none;">Login</a></p>
            </div>
        </form>
    </div>
    </div>
    <script>
        let toastElList = [].slice.call(document.querySelectorAll('.toast'))
        let toastList = toastElList.map(function (toastEl) {
            return new bootstrap.Toast(toastEl, { delay: 3000 });
        });
        toastList.forEach(toast => toast.show());
    </script>
</body>

</html>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="stocky-footer">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; KNGAWA <?php echo date("d-m-Y") ?></span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    
    <!-- Bootstrap core JavaScript-->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.bundle.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="js/jquery.easing.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.js"></script>


</body>

</html>
